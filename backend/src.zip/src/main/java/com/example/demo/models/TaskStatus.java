package com.example.demo.models;

public enum TaskStatus {
    NOT_ASSIGNED,
    IN_PROGRESS,
    COMPLETED
}
