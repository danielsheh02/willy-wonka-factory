package com.example.demo.models;

public enum Role {
    ROLE_WORKER,
    ROLE_FOREMAN
}